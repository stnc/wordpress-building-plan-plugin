<?php
/*
Plugin Name: teknopark kat planları 
Plugin URI:			
Description: teknopark kat planları 	
Version: 1.11.97
Author: selman tunç
Text Domain: chrom_staff
Domain Path: /languages/
*/ 
include ('register.php');